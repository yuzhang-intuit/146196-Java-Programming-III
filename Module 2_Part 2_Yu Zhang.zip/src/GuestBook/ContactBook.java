//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 2_Part 2

package GuestBook;

import javax.swing.SwingUtilities;

public class ContactBook {
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
					new ContactViewController();
			}
		});
	}
}
