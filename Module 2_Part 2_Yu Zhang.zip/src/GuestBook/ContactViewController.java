//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 2_Part 2

package GuestBook;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ContactViewController extends JFrame implements ActionListener{
	//Data field
	private JFrame frame = new JFrame("Contact Book");;
	private JPanel mainPanel = new JPanel();
	private JPanel subPanelA = new JPanel();
	private JPanel subPanelB = new JPanel();
	private JTextArea textArea = new JTextArea(0,2);
	private JScrollPane scrollPane = new JScrollPane(textArea);
	private JLabel firstName = new JLabel ("First Name", JLabel.CENTER);
	private JLabel lastName = new JLabel ("Last Name", JLabel.CENTER);
	private JLabel address = new JLabel ("Address", JLabel.CENTER);
	private JLabel phone = new JLabel ("Phone", JLabel.CENTER);
	private JTextField inputFName = new JTextField(10);
	private JTextField inputLName = new JTextField(10);
	private JTextField inputAddress = new JTextField(30);
	private JTextField inputPhone = new JTextField(20);
	private JButton submit = new JButton ("Submit");
	
	ArrayList <Contact> contactList = new ArrayList<>();
	
	//Constructor
	public ContactViewController() {
		frame.setVisible(true);
		frame.add(mainPanel);
		mainPanel.setLayout(new GridLayout(2, 2));
		mainPanel.add(subPanelA);
		mainPanel.add(scrollPane);
		mainPanel.add(subPanelB);
		subPanelA.setLayout(new GridLayout(4, 2));
		subPanelA.add(firstName);
		subPanelA.add(inputFName);
		subPanelA.add(lastName);
		subPanelA.add(inputLName);
		subPanelA.add(address);
		subPanelA.add(inputAddress);
		subPanelA.add(phone);
		subPanelA.add(inputPhone);
		subPanelB.add(submit);
		submit.addActionListener(this);
		
		frame.pack();
	}
	
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource() == submit) {
			String fName = inputFName.getText();
			String lName = inputLName.getText();
			String addr = inputAddress.getText();
			String phoneNum = inputPhone.getText();
				
			Contact list = new Contact (fName, lName, addr, phoneNum);	
			contactList.add(list);
			
			Set<Contact> cnt= new HashSet<Contact>();
			cnt.addAll(contactList);         
			contactList = new ArrayList<Contact>();
			contactList.addAll(cnt);

			Collections.sort(contactList);
			
			textArea.setText(contactList.toString());
						
			inputFName.setText("");
			inputLName.setText("");
			inputAddress.setText("");
			inputPhone.setText("");
		}
	}
}
