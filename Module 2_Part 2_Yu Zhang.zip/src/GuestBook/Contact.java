//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 2_Part 2

package GuestBook;

import java.util.Objects;

public class Contact implements Comparable<Contact>{
	
	//data field
	private String firstName;
	private String lastName;
	private String address;
	private String phone;
		
	//default constructor
	public Contact () {
	this.firstName = "";
	this.lastName = "";
	this.address = "";
	this.phone = "";
	}
	
	//parameterized constructor
	public Contact (String firstName, String lastName, String address, String phone) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.phone = phone;
	}
	
	public String toString() {
		return String.format("Contact:%nFirst Name: %s%nLast Name: %s%nAddress: %s%nPhone: %s%n%n", firstName, lastName, address, phone);
	}
	
	
	@Override
    public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null || getClass() != obj.getClass()) return false;
		Contact contact = (Contact) obj;
		return  Objects.equals(firstName, contact.firstName) &&
				Objects.equals(lastName, contact.lastName) &&
				Objects.equals(address, contact.address) &&
				Objects.equals(phone, contact.phone);
    }
	
	@Override
    public int hashCode() {
		return Objects.hash(firstName, lastName, address, phone);     
    }
	
	@Override
	public int compareTo(Contact o) {
		return firstName.compareTo(o.firstName);
	}

}
