//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 3_Part 1

package linkedlist;

public class LinkedList <T> implements LinkedListInterface<T> {
	Node head;

	@Override
	public boolean isEmpty() {
		if (head == null) {
			return true;
		}
		return false;
	}

	@Override
	public int size() {
		if (head == null) {
			return 0;
		}
		int count = 0;
		Node current = head;
		while (current != null) {
			count ++;
			current = current.getNext();
		}
		return count;
	}

	@Override
	public void addFirst(T data) {
		Node<T> newNode = new Node<T> (data, null); 
		newNode.next = head; 
		head = newNode;
	}

	@Override
	public void addLast(T data) {
		Node<T> newNode = new Node<T> (data, null);  

	    if (head == null) 
	    { 
	        head = new Node(data, null); 
	        return; 
	    } 

	    newNode.next = null; 

	    Node last = head;  
	    while (last.next != null) 
	        last = last.next; 

	    last.next = newNode; 
	    return; 
	}

	@Override
	public void add(T data, int index) throws IndexOutOfBoundsException {
		if(index < 0 || index>=size()) {
			throw new IndexOutOfBoundsException();
		}
		
		Node<T> newNode = new Node<T> (data, null); 
		if (index == 1) {
			newNode.next = head;
		} else {
			Node previous = head;
			int count = 1;
			while (count < index - 1) {
				previous = previous.next;
				count++;
			}
			Node current = previous.next;
			newNode.next = current;
			previous.next = newNode;
		}
	}

	@Override
	public Node remove(int index) throws IndexOutOfBoundsException {
		if( index < 0 || index>=size() ) {
			throw new IndexOutOfBoundsException();
		}
		
		if( index == 0 ) {
			Node temp = head;
			head = head.next;
			temp.next = null;
			return temp;
		} else {
			Node previous = head;
			int count = 1;
			while (count < index) {
				previous = previous.next;
				count++;
			}
			
			Node current = previous.next;
			previous.next = current.next;
			current.next = null;
			return current;
		}		
	}

	@Override
	public void print() {
		Node nodeList = head; 
        while (nodeList != null) 
        { 
            System.out.print(nodeList.data+" "); 
            nodeList = nodeList.next; 
        } 
	}
}
