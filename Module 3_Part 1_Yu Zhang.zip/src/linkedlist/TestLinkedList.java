//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 3_Part 1

package linkedlist;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestLinkedList {

	@Test
	void testEmpty() {
		LinkedList<String> fruitList = new LinkedList<>();
		assertTrue(fruitList.isEmpty());
		
		fruitList.addFirst("Apple");
		assertTrue(!fruitList.isEmpty());
	}
	
	
	@Test
	void testAddLast() 	{
		LinkedList<String> fruitList = new LinkedList<>();
				
		fruitList.addLast("Apple");
		assertEquals(fruitList.size(),1);
		
		fruitList.addLast("Banana");
		assertEquals(fruitList.size(),2);
		
		fruitList.addLast("Cherry");
		assertEquals(fruitList.size(),3);
		
		fruitList.addLast("Dragonfruit");
		assertEquals(fruitList.size(),4);
		
		assertTrue(!fruitList.isEmpty());
	}
	
	@Test
	void testAddFirst() {
		LinkedList<String> fruitList = new LinkedList<>();
				
		fruitList.addFirst("Apple");
		assertEquals(fruitList.size(),1);
		
		fruitList.addFirst("Banana");
		assertEquals(fruitList.size(),2);
		
		fruitList.addFirst("Cherry");
		assertEquals(fruitList.size(),3);
		
		fruitList.addFirst("Dragonfruit");
		assertEquals(fruitList.size(),4);
		
		assertTrue(!fruitList.isEmpty());
	}
	
	@Test
	void testAddAt() {
		LinkedList<String> fruitList = new LinkedList<>();
		
		fruitList.addFirst("Apple");
		assertEquals(fruitList.size(),1);
		
		fruitList.add("Banana",0);
		assertEquals(fruitList.size(),2);
		
		String [] fruit = {"Cherry", "Dragonfruit"};
		for(int i = 0; i < fruit.length; i++) {
			fruitList.add(fruit[i],0);
		}
		
		assertEquals(fruitList.size(),4);
		assertTrue(!fruitList.isEmpty());
		
		
	}
	
	@Test
	void testRemove() {
		LinkedList<String> fruitList = new LinkedList<>();
		
		String [] fruit = {"Apple", "Banana", "Cherry", "Dragonfruit"};
		for(int i = 0; i < fruit.length; i++) {
			fruitList.addLast(fruit[i]);
		}
		
		String secondNode = (String) fruitList.remove(1).data;
		assertEquals(fruitList.size(),3);
		assertEquals(secondNode,"Banana");
		
	}
}


