//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 3_Part 2

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class MathLearningController {
	private MathLearningModel theModel;
	private MathLearningView theView;
	
	public MathLearningController (MathLearningView theView, MathLearningModel theModel) {
		this.theView = theView;
		this.theModel = theModel;
		CalculateListener listener = new CalculateListener();
		this.theView.addCalculationListener(listener);
		listener.generateAddition();
	}
	
	class CalculateListener implements ActionListener{
		Random randGen = new Random();
		int num1;
		int num2;
		int result;
		int count = 0;
		boolean status;

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource() == theView.addition) {
				generateAddition();
			}
			if (e.getSource()== theView.subtraction) {
				generateSubtraction();
			}
			if (e.getSource() == theView.submit) {
			try {
				int inputNum = theView.getAnswerNumber();
				if (result==inputNum) {
					theView.feedback.setText("Correct!"+count+" wrong attempts.");
				
					count=0;
					theView.answer.setText("");//make text box blank to be ready for next input
					
					if(status) {
						generateAddition();
					}else {
						generateSubtraction();
					}
				}
				else {
					theView.feedback.setText("Wrong! Try again.");
					theView.answer.setText("");//make text box blank to be ready for next input
					count++;
				}
			}catch(NumberFormatException exp) {
				count++;
				theView.feedback.setText("Error! Enter an integer value. Try again");
				theView.answer.setText("");
			}
			
		}
		}
		
		private void generateAddition() {
			num1 = randGen.nextInt(10);
			num2 = randGen.nextInt(10);
			theView.question.setText(num1+" + "+num2+" = ");
			theModel.addition(num1, num2);
			result = theModel.getAdditionValue();
			status = true;//make sure the next question is still be addition
		}
		
		private void generateSubtraction() {
			num1 = randGen.nextInt(10);
			num2 = randGen.nextInt(num1+1);//num2<=num1
			theView.question.setText(num1+" - "+num2+" = ");
			theModel.subtraction(num1, num2);
			result = theModel.getSubtractionValue();
			status = false;//make sure the next question is still be subtraction
		}
		
	}

}
