//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 3_Part 2

import javax.swing.*;//JLabel/JButton/JTextField
import java.awt.*;//layout
import java.awt.event.*;//actionEvent e
import java.util.Random;

public class MathLearningView extends JFrame{
	JButton addition=new JButton("Addition");
	JButton subtraction=new JButton("Subtraction");
	JLabel question = new JLabel("");
	JTextField answer = new JTextField(10);
	JButton submit = new JButton("Submit");
	JLabel feedback = new JLabel();//provide feedback when user enter value
	
	//constructor
	public MathLearningView(){
		//super
		super("Math Learning Tool");
		
		//set up
		setSize(400,200);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new GridLayout(0,2));
		
		//add
		add(addition);
		add(subtraction);
		add(question);
		add(answer);
		add(submit);
		add(feedback);
	}
	public int getAnswerNumber() {
		return Integer.parseInt(answer.getText());
	}
	
	public void addCalculationListener (ActionListener listenForButton) {
		addition.addActionListener(listenForButton);
		subtraction.addActionListener(listenForButton);
		submit.addActionListener(listenForButton);
	}
}