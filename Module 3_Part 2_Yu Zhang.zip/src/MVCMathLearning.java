//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 3_Part 2

public class MVCMathLearning {

	public static void main(String[] args) {
		MathLearningView theView = new MathLearningView();
		MathLearningModel theModel = new MathLearningModel();
		MathLearningController theController = new MathLearningController(theView, theModel);
		theView.setVisible(true);

	}

}
