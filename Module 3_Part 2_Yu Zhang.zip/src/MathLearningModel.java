//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 3_Part 2

public class MathLearningModel {
	
	private int correctAdditionValue;
	private int correctSubtractionValue;
	
	public void addition(int num1, int num2) {
		correctAdditionValue = num1 + num2;
	}
	
	public int getAdditionValue() {
		return correctAdditionValue;
	}
	
	public void subtraction(int num1, int num2) {
		correctSubtractionValue = num1 - num2;
	}
	
	public int getSubtractionValue() {
		return correctSubtractionValue;
	}

}
