//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 1

import javax.swing.*;

public class Hexadecimal {
	
	public Hexadecimal() {
		
	}
	
	public void convertToBinary() {
		String hb = JOptionPane.showInputDialog("Enter Hexadecimal to be converted to Binary:");
		String digits = "0123456789ABCDEF";  
        hb = hb.toUpperCase();  
        int decimal = 0;  
        for (int i = 0; i < hb.length(); i++)  
        {  
            char c = hb.charAt(i);  
            int d = digits.indexOf(c);  
            decimal = 16*decimal + d;  
        }
        
        int i=1, j;
        int binary[] = new int[100];
        while(decimal != 0){
    	    binary[i++] = decimal%2;
    	    decimal = decimal/2;
    	    }
        String str = "";
        for(j=i-1; j>0; j--){
        	str = str + String.valueOf(binary[j]);
        }
        JOptionPane.showMessageDialog(null, "Binary represenation of " + hb + " is " + str );
	}
	
	public void convertToDecimal() {
		String hd = JOptionPane.showInputDialog("Enter Hexadecimal to be converted to Decimal:");
		String digits = "0123456789ABCDEF";  
        hd = hd.toUpperCase();  
        int decimal = 0;  
        for (int i = 0; i < hd.length(); i++)  
        {  
            char c = hd.charAt(i);  
            int d = digits.indexOf(c);  
            decimal = 16*decimal + d;  
        }  
        JOptionPane.showMessageDialog(null, "Decimal represenation of " + hd + " is " + decimal );
	}

}
