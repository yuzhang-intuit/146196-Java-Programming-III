//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 1

import javax.swing.JOptionPane;

public class Binary {
	
	public Binary() {
		
	}
	public void convertToDecimal() {
		String bd = JOptionPane.showInputDialog("Enter Binary to be converted to Decimal:");
		int num = Integer.parseInt(bd);
		int decimal = 0;
	    int p = 0;
	    while(true){
	      if(num == 0){
	        break;
	      } else {
	          int temp = num%10;
	          decimal += temp*Math.pow(2, p);
	          num = num/10;
	          p++;
	      }
	    }
		
	    JOptionPane.showMessageDialog(null, "Decimal represenation of " + bd + " is " + decimal );
	}
	
	public void convertToHexadecimal() {
		String bh = JOptionPane.showInputDialog("Enter Binary to be converted to Hexadecimal:");
		int num = Integer.parseInt(bh);
		int rem;
		String hexdecnum = "";
		
		char hex[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
		
		while(num>0)
        {
            rem = num%16;
            hexdecnum = hex[rem] + hexdecnum;
            num = num/16;
        }
		JOptionPane.showMessageDialog(null, "Hexadecimal represenation of " + bh + " is " + hexdecnum );
	}
	
}
