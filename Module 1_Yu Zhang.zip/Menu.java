//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 1

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Menu implements ActionListener {

	private JFrame frame;
	private JPanel panel;
	private JButton binToDec;
	private JButton binToHex;
	private JButton decToBin;
	private JButton decToHex;
	private JButton hexToBin;
	private JButton hexToDec;
	private Binary binary;
	private Decimal decimal;
	private Hexadecimal hexadecimal;
	
	public Menu(Binary binary, Decimal decimal, Hexadecimal hexadecimal) {
		this.frame = new JFrame("Number Systems");
		this.panel = new JPanel();
		this.binToDec = new JButton("Bin to Dec");
		this.binToHex = new JButton("Bin to Hex");
		this.decToBin = new JButton("Dec to Bin");
		this.decToHex = new JButton("Dec to Hex");
		this.hexToBin = new JButton("Hex to Bin");
		this.hexToDec = new JButton("Hex to Dec");
		this.binary = binary;
		this.decimal = decimal;
		this.hexadecimal = hexadecimal;
		
	}
	
	public void show() {
		frame.setVisible(true);
		frame.add(panel);
		panel.add(binToDec);
		panel.add(binToHex);
		panel.add(decToBin);
		panel.add(decToHex);
		panel.add(hexToBin);
		panel.add(hexToDec);
		frame.pack();		

		binToDec.addActionListener(this);
		binToHex.addActionListener(this);
		decToBin.addActionListener(this);
		decToHex.addActionListener(this);
		hexToBin.addActionListener(this);
		hexToDec.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		//Binary
		if(e.getSource() == binToDec) {
			binary.convertToDecimal();
			}
		if (e.getSource() == binToHex) {
			binary.convertToHexadecimal();
		}
		
		//Decimal
		if(e.getSource() == decToBin) {
			decimal.convertToBinary();
		}
		if(e.getSource() == decToHex) {
			decimal.convertToHexidecimal();
		}
		
		//Hexadecimal
		if(e.getSource() == hexToBin) {
			hexadecimal.convertToBinary();
		}
		if(e.getSource() == hexToDec) {
			hexadecimal.convertToDecimal();
		}
	}

}
