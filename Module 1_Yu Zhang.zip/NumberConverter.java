//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 1

public class NumberConverter {
	
	private Menu menu;
	
	public NumberConverter() {
		Binary binary = new Binary();
		Decimal decimal = new Decimal();
		Hexadecimal hexadecimal = new Hexadecimal();
		this.menu = new Menu(binary, decimal, hexadecimal);
	}
	
	public static void main(String[] args) {
		NumberConverter numberConverter = new NumberConverter();
		numberConverter.menu.show();
	}

}
