//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 1

import javax.swing.*;

public class Decimal {
	
	public Decimal() {
		
	}
	public void convertToBinary() {
		String db = JOptionPane.showInputDialog("Enter Decimal to be converted to Binary:");
		int num = Integer.parseInt(db);
		int i=1, j;
        int binary[] = new int[100];
        while(num != 0){
    	    binary[i++] = num%2;
    	    num = num/2;
    	    }
        String str = "";
        for(j=i-1; j>0; j--){
        	str = str + String.valueOf(binary[j]);
        }
        JOptionPane.showMessageDialog(null, "Binary represenation of " + db + " is " + str );
	}
	
	public void convertToHexidecimal() {
		String dh = JOptionPane.showInputDialog("Enter Decimal to be converted to Hexadecimal:");
		int num = Integer.parseInt(dh);
		int rem;
	    String hexdecnum=""; 
	    
	    char hex[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	 
	    while(num > 0){
	    	rem=num%16; 
	    	hexdecnum=hex[rem]+hexdecnum; 
	    	num=num/16;
	    }
	    JOptionPane.showMessageDialog(null, "Hexadecimal represenation of " + dh + " is " + hexdecnum );
	}

}
