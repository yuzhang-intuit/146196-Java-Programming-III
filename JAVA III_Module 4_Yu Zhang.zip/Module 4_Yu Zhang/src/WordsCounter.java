//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 4

public class WordsCounter {

	public static void main(String[] args) {
		new Menu().createUI();
	}
}
