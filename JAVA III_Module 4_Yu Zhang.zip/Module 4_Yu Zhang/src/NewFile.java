//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 4

public class NewFile {
	//get input from scanner and create a new file
	String fileName = "";
	int totalWords = 0;
	public NewFile(String fileName, int totalWords) {
		super();
		this.fileName = fileName;
		this.totalWords = totalWords;
	}
	public String getFilename() {
		return fileName;
	}
	public int getWordsCount() {
		return totalWords;
	}
 

}
