//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 4

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import javax.swing.*;
import javax.swing.filechooser.FileSystemView;

public class Menu implements ActionListener {
	//Data fields
	JFrame frame = new JFrame("Word Counter");
	JPanel panel = new JPanel();
	JButton addFile = new JButton();
	JButton count = new JButton();
	JTextArea results = new JTextArea();
	File[] files;
	static JLabel label = new JLabel("No File Selected");;
	
	ExecutorService executor;
	
	public void createUI() {
		frame.setLayout(new GridLayout(3,3));
		frame.setBounds(20,20,400,400);
		frame.setVisible(true);
		frame.add(panel);
		JScrollPane theScroller = new JScrollPane(results,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.add(theScroller);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel.add(addFile);
		panel.add(count);
		panel.add(label);
		
		addFile.setText("Add File(s)");
		count.setText("Count Words");
		
		frame.pack();
		
		addFile.addActionListener(this);
		count.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == addFile) {
			JFileChooser j = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
			j.setMultiSelectionEnabled(true);
			int r = j.showSaveDialog(null); 
			if (r == JFileChooser.APPROVE_OPTION) { 
				files = j.getSelectedFiles();
				String message="";
				for (int i = 0; i < files.length; i++) {
					String tempFileName = files[i].getName();	
					message += tempFileName+"\n";
				}
					results.setText(message);
					label.setText("File(s) Added");
				}
				else 
					label.setText("Operation Cancelled"); 
	        } 
		
		if(event.getSource() == count) {
			long begin = System.currentTimeMillis();  //Time mill begins
			
			//create threads
			this.executor = Executors.newFixedThreadPool(files.length); 
			@SuppressWarnings("unchecked")
			
			//assign a thread to each file
			Future<NewFile>[] allFiles = new Future[files.length];
			for (int i = 0; i < files.length; i++) {
				File nextFile = files[i];
				allFiles[i] = this.executor.submit(new ScanFile(nextFile));
			}
			this.executor.shutdown();
		
			//collect results from each thread
			try {
				executor.awaitTermination(3000,TimeUnit.MILLISECONDS);
				String message="";	
				for (int i = 0; i < allFiles.length; i++) {
					Future<NewFile> temp = allFiles[i];
					if(temp.isDone()) { 
						NewFile instance = temp.get();
						String tempFileName = instance.getFilename();
						int tempWordCount = instance.getWordsCount();
						message += tempFileName + ": "+tempWordCount+"\n";
					}
				}
				results.setText(message);
				label.setText("Words Counted");
			} 
			catch (InterruptedException e) {
				e.printStackTrace();
			} 
			catch (ExecutionException e) {
				e.printStackTrace();
			}
			
			long end = System.currentTimeMillis();  //Time mill ends
			System.out.println(end - begin);
		}
	}
}
