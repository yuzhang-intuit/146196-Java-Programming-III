//Name: Yu Zhang
//Student ID: U08538802
//Assignment: Module 4

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.concurrent.Callable;

public class ScanFile implements Callable<NewFile> {
	File fRead;
	int totalWords=0;
	public  ScanFile(File fRead) { 
		this.fRead=fRead;
	}
	public NewFile call() {
		Scanner sc = null;
		try {
			sc = new Scanner(fRead);
			while (sc.hasNextLine()) {
				String fileLine = sc.nextLine();	
				String[] allWords = fileLine.split(" ");	
				totalWords += allWords.length;	
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		return new NewFile(fRead.getName(),totalWords);  
	} 
}